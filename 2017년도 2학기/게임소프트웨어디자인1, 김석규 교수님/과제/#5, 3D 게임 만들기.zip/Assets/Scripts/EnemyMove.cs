﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMove : MonoBehaviour
{

	const int MinLane = 2;
	const int MaxLane = 2;
	const float LaneWidth = 1.0f;

	CharacterController controller;
	Animator animator;

	Vector3 moveDirection = Vector3.zero;
	int targetLane;

	// Use this for initialization
	void Start()
	{
		// 필요한 컴포넌트를 자동 취득
		controller = GetComponent<CharacterController>();
		animator = GetComponent<Animator>();
	}

	// Update is called once per frame
	void Update()
	{
		transform.Translate(Vector3.back * (Time.deltaTime * 3), Space.World);

		animator.SetTrigger("walk");
	}
}
